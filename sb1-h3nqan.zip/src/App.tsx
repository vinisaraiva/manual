import { useState } from 'react';
import { useNavigate, Routes, Route } from 'react-router-dom';
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, BookOpen, Code, Info, Home, Map, UserPlus, FileText, BarChart2, Droplet, AlertCircle, FileSpreadsheet, Users, Bell } from 'lucide-react';

const translations = {
  'pt-BR': {
    manualDeUso: 'Manual de Uso',
    api: 'API',
    outrasInformacoes: 'Outras Informações',
    tituloManual: 'Manual de Uso da Plataforma TIKATU',
    introducaoManual: 'A plataforma TIKATU foi desenvolvida para o monitoramento da qualidade da água, oferecendo funcionalidades que auxiliam os usuários na análise de dados ambientais e no controle de indicadores essenciais de rios. Este manual foi criado para guiar o usuário passo a passo sobre como utilizar todas as páginas da aplicação.',
    paginaInicial: 'Página Inicial',
    paginaMonitoramento: 'Página de Monitoramento',
    paginaCadastro: 'Página de Cadastro',
    paginaAnalise: 'Página "Faça sua Análise"',
    paginaIQA: 'Página "Análise IQA"',
    consideracoesFinais: 'Considerações Finais',
    outrasInformacoesConteudo: 'Nesta seção você encontrará outras informações úteis sobre a plataforma Tikatu. A plataforma Tikatu também oferece suporte ao monitoramento colaborativo, onde diferentes usuários podem contribuir com dados e análises de qualidade da água. Além disso, a plataforma está integrada com sistemas de notificação para alertas em tempo real, garantindo uma resposta rápida em caso de parâmetros críticos.',
    monitoramentoColaborativo: 'Monitoramento Colaborativo',
    alertasTempoReal: 'Alertas em Tempo Real',
  },
  'en': {
    manualDeUso: 'User Manual',
    api: 'API',
    outrasInformacoes: 'Other Information',
    tituloManual: 'TIKATU Platform User Manual',
    introducaoManual: 'The TIKATU platform was developed for water quality monitoring, offering features that assist users in analyzing environmental data and controlling essential river indicators. This manual was created to guide the user step by step on how to use all pages of the application.',
    paginaInicial: 'Home Page',
    paginaMonitoramento: 'Monitoring Page',
    paginaCadastro: 'Registration Page',
    paginaAnalise: 'Make Your Analysis Page',
    paginaIQA: 'WQI Analysis Page',
    consideracoesFinais: 'Final Considerations',
    outrasInformacoesConteudo: 'In this section, you will find other useful information about the Tikatu platform. The Tikatu platform also supports collaborative monitoring, where different users can contribute data and water quality analyses. Additionally, the platform is integrated with notification systems for real-time alerts, ensuring a quick response in case of critical parameters.',
    monitoramentoColaborativo: 'Collaborative Monitoring',
    alertasTempoReal: 'Real-time Alerts',
  }
};

function App() {
  const [language, setLanguage] = useState('pt-BR');
  const t = translations[language];
  const navigate = useNavigate();

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'pt-BR' ? 'en' : 'pt-BR');
  };

  const SidebarContent = () => (
    <nav className="flex flex-col space-y-2">
      <Button variant="ghost" className="justify-start" onClick={() => navigate('/')}>
        <BookOpen className="mr-2 h-4 w-4" />
        {t.manualDeUso}
      </Button>
      <Button variant="ghost" className="justify-start" onClick={() => navigate('/api')}>
        <Code className="mr-2 h-4 w-4" />
        {t.api}
      </Button>
      <Button variant="ghost" className="justify-start" onClick={() => navigate('/outras')}>
        <Info className="mr-2 h-4 w-4" />
        {t.outrasInformacoes}
      </Button>
    </nav>
  );

  const ManualContent = () => (
    <div className="space-y-8">
      <section className="bg-white p-6 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold mb-4">{t.tituloManual}</h1>
        <p className="mb-4">{t.introducaoManual}</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><Home className="mr-2 h-6 w-6 text-blue-500" />{t.paginaInicial}</h2>
        <p>A página inicial é informativa e fornece um panorama sobre a plataforma e seus objetivos.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><Map className="mr-2 h-6 w-6 text-green-500" />{t.paginaMonitoramento}</h2>
        <p>Esta página é onde o usuário pode acompanhar os dados dos rios monitorados.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><UserPlus className="mr-2 h-6 w-6 text-purple-500" />{t.paginaCadastro}</h2>
        <p>Esta página é dedicada ao cadastro de novos usuários e para a gestão de informações dos rios monitorados.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><FileText className="mr-2 h-6 w-6 text-yellow-500" />{t.paginaAnalise}</h2>
        <p>Nesta página, os usuários podem realizar análises personalizadas com base nos dados de qualidade da água.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><BarChart2 className="mr-2 h-6 w-6 text-red-500" />{t.paginaIQA}</h2>
        <p>Esta página é focada no índice de qualidade da água (IQA), que fornece um indicador geral da qualidade da água em cada ponto de coleta.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><AlertCircle className="mr-2 h-6 w-6 text-orange-500" />{t.consideracoesFinais}</h2>
        <p>A plataforma TIKATU foi desenvolvida para ser simples e intuitiva, auxiliando desde profissionais da área ambiental até cidadãos que desejam monitorar a qualidade da água em suas regiões. Utilize este manual sempre que precisar de ajuda para navegar pelas funcionalidades da plataforma.</p>
      </section>
    </div>
  );

  const ApiContent = () => (
    <div className="space-y-8">
      <section className="bg-white p-6 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold mb-4">API da Tikatu</h1>
        <h2 className="text-2xl font-bold mb-2">1. Introdução</h2>
        <p>A API da Tikatu é uma interface que permite que aplicações externas enviem dados sobre a qualidade da água monitorada. Esta API foi desenvolvida para ser simples e acessível, facilitando a integração com diferentes sistemas que necessitam coletar dados ambientais.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-2">2. Estrutura da API</h2>
        <h3 className="text-xl font-semibold mb-2">2.1. Endpoints</h3>
        <p><strong>POST /api/dados</strong></p>
        <p>Esse endpoint é utilizado para receber dados de qualidade da água.</p>
        <ul className="list-disc list-inside mb-2">
          <li>Método HTTP: POST</li>
          <li>URL: https://api.tikatu.com.br/api/dados</li>
        </ul>
        <h3 className="text-xl font-semibold mb-2">2.2. Como Funciona</h3>
        <p>Quando você enviar uma requisição para este endpoint, a API processará os dados fornecidos e os armazenará para análise futura. É importante que todos os dados sejam enviados no formato correto para garantir que a requisição seja aceita.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-2">3. Enviando Dados</h2>
        <h3 className="text-xl font-semibold mb-2">3.1. Formato da Requisição</h3>
        <p>A requisição deve ser feita em formato JSON e deve incluir os nove parâmetros utilizados para o cálculo do Índice de Qualidade da Água (IQA):</p>
        <h4 className="text-lg font-semibold mb-2">Estrutura do JSON</h4>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "nome_rio": "Nome do Rio",
  "turbidez": 20.5,
  "pH": 7.2,
  "salinidade": 0.5,
  "temperatura": 22.0,
  "oxigenio_disolvido": 8.0,
  "demanda_quimica_de_oxigenio": 15.0,
  "nitrogenio_total": 0.5,
  "fosforo_total": 0.2,
  "data_coleta": "2024-10-04T15:00:00Z",
  "localizacao": {
    "latitude": -15.0,
    "longitude": -38.0
  }
}`}</code>
        </pre>
        <h3 className="text-xl font-semibold mt-4 mb-2">3.2. Campos da Requisição</h3>
        <ul className="list-disc list-inside">
          <li><strong>nome_rio</strong> (string): Nome do rio monitorado. Obrigatório.</li>
          <li><strong>turbidez</strong> (float): Valor de turbidez em NTU (Unidade de Nefelométrica de Turbidez). Obrigatório.</li>
          <li><strong>pH</strong> (float): Valor de pH da água. Obrigatório.</li>
          <li><strong>salinidade</strong> (float): Valor de salinidade em PSU (Practical Salinity Unit). Obrigatório.</li>
          <li><strong>temperatura</strong> (float): Temperatura da água em graus Celsius. Obrigatório.</li>
          <li><strong>oxigenio_disolvido</strong> (float): Valor de oxigênio dissolvido em mg/L. Obrigatório.</li>
          <li><strong>demanda_quimica_de_oxigenio</strong> (float): Valor da Demanda Química de Oxigênio (DQO) em mg/L. Obrigatório.</li>
          <li><strong>nitrogenio_total</strong> (float): Valor de nitrogênio total em mg/L. Obrigatório.</li>
          <li><strong>fosforo_total</strong> (float): Valor de fósforo total em mg/L. Obrigatório.</li>
          <li><strong>data_coleta</strong> (string): Data e hora da coleta no formato ISO 8601 (ex: 2024-10-04T15:00:00Z). Obrigatório.</li>
          <li><strong>localizacao</strong> (objeto): Informações de localização.
            <ul className="list-disc list-inside ml-4">
              <li><strong>latitude</strong> (float): Latitude da coleta. Obrigatório.</li>
              <li><strong>longitude</strong> (float): Longitude da coleta. Obrigatório.</li>
            </ul>
          </li>
        </ul>
        <h3 className="text-xl font-semibold mt-4 mb-2">3.3. Exemplo de Requisição</h3>
        <h4 className="text-lg font-semibold mb-2">Usando cURL</h4>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`curl -X POST https://api.tikatu.com.br/api/dados \\
-H "Content-Type: application/json" \\
-d '{
  "nome_rio": "Rio Azul",
  "turbidez": 25.3,
  "pH": 7.1,
  "salinidade": 0.3,
  "temperatura": 20.0,
  "oxigenio_disolvido": 8.0,
  "demanda_quimica_de_oxigenio": 15.0,
  "nitrogenio_total": 0.5,
  "fosforo_total": 0.2,
  "data_coleta": "2024-10-04T15:00:00Z",
  "localizacao": {
    "latitude": -15.0,
    "longitude": -38.0
  }
}'`}</code>
        </pre>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-2">4. Respostas da API</h2>
        <p>Após enviar os dados, você receberá uma resposta da API.</p>
        <h3 className="text-xl font-semibold mb-2">4.1. Códigos de Resposta</h3>
        <h4 className="text-lg font-semibold mb-2">201 - Criado</h4>
        <p>Indica que os dados foram recebidos e armazenados com sucesso.</p>
        <p>Exemplo de Resposta:</p>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "status": "sucesso",
  "dados_recebidos": {
    "nome_rio": "Rio Azul",
    ...
  }
}`}</code>
        </pre>
        <h4 className="text-lg font-semibold mt-4 mb-2">400 - Erro de Validação</h4>
        <p>Indica que a requisição não pôde ser processada devido a campos obrigatórios ausentes ou dados inválidos.</p>
        <p>Exemplo de Resposta:</p>
        <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto">
          <code>{`{
  "error": "Campo 'nome_rio' é obrigatório."
}`}</code>
        </pre>
        <h3 className="text-xl font-semibold mt-4 mb-2">4.2. Como Lidar com Respostas</h3>
        <ul className="list-disc list-inside">
          <li><strong>Sucesso:</strong> Se você receber um código 201, os dados foram armazenados corretamente.</li>
          <li><strong>Erro:</strong> Se você receber um código 400, verifique a mensagem de erro para entender qual campo está faltando ou está incorreto.</li>
        </ul>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-2">5. Segurança</h2>
        <p>Para garantir a integridade e a segurança da API, as organizações ou usuários interessados em integrar com a API da Tikatu devem seguir o seguinte processo:</p>
        <ol className="list-decimal list-inside">
          <li><strong>Contato Inicial:</strong> Entre em contato pelo e-mail contato@tikatu.com.br.</li>
          <li><strong>Cadastro:</strong> Efetue um cadastro informando detalhes sobre sua organização e as formas de coleta de dados que pretende utilizar.</li>
          <li><strong>Verificação:</strong> A equipe da Tikatu realizará uma verificação sobre a confiabilidade dos dados que serão enviados.</li>
          <li><strong>Recebimento de Token:</strong> Após a validação, você receberá um token que permitirá a integração com a API.</li>
        </ol>
        <p className="mt-2">Este processo ajuda a garantir que a API seja utilizada de maneira segura e confiável.</p>
      </section>

      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-2">6. Considerações Finais</h2>
        <ul className="list-disc list-inside">
          <li><strong>Validação de Dados:</strong> Sempre verifique se os dados estão no formato correto e seguem as regras de validação antes de enviar.</li>
          <li><strong>Monitoramento:</strong> Monitore as respostas da API e faça ajustes conforme necessário para garantir que a integração funcione de forma fluida.</li>
          <li><strong>Suporte:</strong> Para qualquer dúvida ou problema durante a integração, entre em contato com o suporte técnico pelo e-mail mencionado.</li>
        </ul>
      </section>
    </div>
  );

  const OtherInformationContent = () => (
    <div className="space-y-8">
      <section className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 flex items-center"><Info className="mr-2 h-6 w-6 text-blue-500" />{t.outrasInformacoes}</h2>
        <p>{t.outrasInformacoesConteudo}</p>
      </section>
      <section className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-semibold mb-2 flex items-center"><Users className="mr-2 h-5 w-5 text-green-500" />{t.monitoramentoColaborativo}</h3>
        <p>{t.outrasInformacoesConteudo}</p>
      </section>
      <section className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-semibold mb-2 flex items-center"><Bell className="mr-2 h-5 w-5 text-yellow-500" />{t.alertasTempoReal}</h3>
        <p>{t.outrasInformacoesConteudo}</p>
      </section>
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-[#f2f5fc]">
      {/* Top bar */}
      <header className="bg-[#e6f3fc] p-4 flex justify-between items-center">
        <div className="flex items-center">
          <Droplet className="h-8 w-8 text-blue-500 mr-2" />
          <h1 className="text-2xl font-bold text-blue-700">TIKATU</h1>
        </div>
        <Button onClick={toggleLanguage} className="flex items-center gap-2">
          {language === 'pt-BR' ? '🇺🇸 EN' : '🇧🇷 PT-BR'}
        </Button>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Fixed Sidebar for larger screens */}
        <aside className="hidden lg:flex w-64 flex-col p-4 border-r bg-white">
          <SidebarContent />
        </aside>

        {/* Mobile menu */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="fixed top-4 left-4 z-50 lg:hidden">
              <Menu className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[240px] sm:w-[300px]">
            <SidebarContent />
          </SheetContent>
        </Sheet>

        {/* Main content */}
        <main className="flex-1 overflow-auto p-8">
          <Routes>
            <Route path="/" element={<ManualContent />} />
            <Route path="/api" element={<ApiContent />} />
            <Route path="/outras" element={<OtherInformationContent />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default App;